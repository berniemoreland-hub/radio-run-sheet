RADIO RUN SHEET — BUILD-027
GITHUB PAGES / AUTO-UPDATE WEB VERSION

REPOSITORY:
https://github.com/berniemoreland-hub/radio-run-sheet

PERMANENT WEB ADDRESS:
https://berniemoreland-hub.github.io/radio-run-sheet/

FILES TO UPLOAD TO THE ROOT OF THE GITHUB REPOSITORY:
- index.html
- version.json

OPTIONAL LOCAL LAUNCHER:
- Launch Radio Run Sheet.bat

ONE-TIME GITHUB SETUP

1. Open:
   https://github.com/berniemoreland-hub/radio-run-sheet

2. Upload index.html and version.json to the ROOT of the repository.
   Commit the files to the main branch.

3. Open the repository's Settings tab.

4. Choose Pages in the left sidebar.

5. Under Build and deployment:
   Source: Deploy from a branch
   Branch: main
   Folder: / (root)

6. Click Save.

7. GitHub will publish the planner at:
   https://berniemoreland-hub.github.io/radio-run-sheet/

HOW AUTO-UPDATING WORKS

The web address never changes. Future builds replace index.html in the GitHub
repository. Anyone opening the permanent web address receives the newest
published build, so there is no new ZIP to download each time.

The included Launch Radio Run Sheet.bat opens that permanent web address.
You only need to keep this launcher once.

IMPORTANT ABOUT SAVED NOTES

The web-hosted planner uses browser localStorage. Notes are saved in the browser
on the same computer/browser profile. Because the GitHub Pages URL stays the
same between builds, notes can persist across future web updates.

BUILD NUMBER

The current build number appears in small print at the bottom-right of the
show planner and will continue to increment with future builds.
