@echo off
start "" "https://berniemoreland-hub.github.io/radio-run-sheet/"
